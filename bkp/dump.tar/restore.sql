--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2 (Debian 12.2-2.pgdg100+1)
-- Dumped by pg_dump version 12.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: cliente; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA cliente;


ALTER SCHEMA cliente OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliente; Type: TABLE; Schema: cliente; Owner: postgres
--

CREATE TABLE cliente.cliente (
    idcliente integer NOT NULL,
    nome character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    senha character varying(255) NOT NULL
);


ALTER TABLE cliente.cliente OWNER TO postgres;

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE; Schema: cliente; Owner: postgres
--

CREATE SEQUENCE cliente.cliente_idcliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cliente.cliente_idcliente_seq OWNER TO postgres;

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE OWNED BY; Schema: cliente; Owner: postgres
--

ALTER SEQUENCE cliente.cliente_idcliente_seq OWNED BY cliente.cliente.idcliente;


--
-- Name: abastecimento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.abastecimento (
    idabastecimento integer NOT NULL,
    data date,
    cidade character varying(255),
    cnpj integer,
    quantidade double precision,
    valortotal double precision,
    valorunitario double precision,
    posto character varying(255),
    produto character varying(255),
    hodometro double precision
);


ALTER TABLE public.abastecimento OWNER TO postgres;

--
-- Name: abastecimento_idabastecimento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.abastecimento_idabastecimento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.abastecimento_idabastecimento_seq OWNER TO postgres;

--
-- Name: abastecimento_idabastecimento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.abastecimento_idabastecimento_seq OWNED BY public.abastecimento.idabastecimento;


--
-- Name: chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat (
    idchat integer NOT NULL,
    idusuarioorigem integer,
    idusuariodestino integer,
    mensagem text,
    visualizada boolean DEFAULT false,
    datahoraenvio timestamp without time zone,
    datahoravisualizacao timestamp without time zone
);


ALTER TABLE public.chat OWNER TO postgres;

--
-- Name: chat_idchat_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chat_idchat_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chat_idchat_seq OWNER TO postgres;

--
-- Name: chat_idchat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chat_idchat_seq OWNED BY public.chat.idchat;


--
-- Name: colaborador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colaborador (
    idcolaborador integer NOT NULL,
    nome character varying(255) NOT NULL,
    cpf character varying(15) NOT NULL,
    email character varying(255),
    idfilial integer NOT NULL,
    idsituacaousuario integer DEFAULT 2
);


ALTER TABLE public.colaborador OWNER TO postgres;

--
-- Name: colaborador_idcolaborador_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colaborador_idcolaborador_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.colaborador_idcolaborador_seq OWNER TO postgres;

--
-- Name: colaborador_idcolaborador_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colaborador_idcolaborador_seq OWNED BY public.colaborador.idcolaborador;


--
-- Name: ferias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ferias (
    idferias integer NOT NULL,
    datainclusao timestamp without time zone DEFAULT now() NOT NULL,
    datainicio date NOT NULL,
    datafim date NOT NULL,
    idcolaborador integer NOT NULL,
    ativo character(1) DEFAULT 1 NOT NULL
);


ALTER TABLE public.ferias OWNER TO postgres;

--
-- Name: ferias_idferias_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ferias_idferias_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ferias_idferias_seq OWNER TO postgres;

--
-- Name: ferias_idferias_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ferias_idferias_seq OWNED BY public.ferias.idferias;


--
-- Name: filial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.filial (
    idfilial integer NOT NULL,
    fantasia character varying(255),
    uf character varying(2),
    numerofilial integer,
    cnpj character varying
);


ALTER TABLE public.filial OWNER TO postgres;

--
-- Name: localizacao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.localizacao (
    idveiculo integer NOT NULL,
    datahora timestamp without time zone NOT NULL,
    longitude character varying(255) NOT NULL,
    latitude character varying(255) NOT NULL
);


ALTER TABLE public.localizacao OWNER TO postgres;

--
-- Name: multa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.multa (
    idmulta integer NOT NULL,
    prefixo integer NOT NULL,
    data date,
    placa character varying(255),
    infracao text,
    nomemotorista character varying(255),
    matriculamotorista character varying(255),
    local character varying(255),
    valorinflacao numeric NOT NULL,
    valorpago numeric
);


ALTER TABLE public.multa OWNER TO postgres;

--
-- Name: multa_idmulta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.multa_idmulta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.multa_idmulta_seq OWNER TO postgres;

--
-- Name: multa_idmulta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.multa_idmulta_seq OWNED BY public.multa.idmulta;


--
-- Name: ocorrencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ocorrencia (
    idocorrencia integer NOT NULL,
    idusuario integer NOT NULL,
    idusuarioinclusao integer NOT NULL,
    datainclusao timestamp without time zone NOT NULL,
    idtipoocorrencia integer NOT NULL,
    dataocorrencia date NOT NULL
);


ALTER TABLE public.ocorrencia OWNER TO postgres;

--
-- Name: ocorrencia_idocorrencia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ocorrencia_idocorrencia_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ocorrencia_idocorrencia_seq OWNER TO postgres;

--
-- Name: ocorrencia_idocorrencia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ocorrencia_idocorrencia_seq OWNED BY public.ocorrencia.idocorrencia;


--
-- Name: situacaousuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.situacaousuario (
    idsituacaousuario integer NOT NULL,
    descricao character varying(255) NOT NULL
);


ALTER TABLE public.situacaousuario OWNER TO postgres;

--
-- Name: situacaousuario_idsituacaousuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.situacaousuario_idsituacaousuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.situacaousuario_idsituacaousuario_seq OWNER TO postgres;

--
-- Name: situacaousuario_idsituacaousuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.situacaousuario_idsituacaousuario_seq OWNED BY public.situacaousuario.idsituacaousuario;


--
-- Name: tipoocorrencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipoocorrencia (
    idtipoocorrencia integer NOT NULL,
    nome character varying(255) NOT NULL,
    descricao character varying(255) NOT NULL
);


ALTER TABLE public.tipoocorrencia OWNER TO postgres;

--
-- Name: tipoocorrencia_idtipoocorrencia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipoocorrencia_idtipoocorrencia_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipoocorrencia_idtipoocorrencia_seq OWNER TO postgres;

--
-- Name: tipoocorrencia_idtipoocorrencia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipoocorrencia_idtipoocorrencia_seq OWNED BY public.tipoocorrencia.idtipoocorrencia;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    idusuario integer NOT NULL,
    idsituacaousuario integer,
    idfilial integer,
    nome character varying(255),
    email character varying(255),
    senha character varying(255),
    status integer,
    foto text,
    cpf character varying,
    datanascimento date,
    admissao date,
    idcargousuario integer
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_idusuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_idusuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_idusuario_seq OWNER TO postgres;

--
-- Name: usuario_idusuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_idusuario_seq OWNED BY public.usuario.idusuario;


--
-- Name: veiculo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.veiculo (
    idveiculo integer NOT NULL,
    idfilial integer,
    prefixo integer,
    tipo character varying(255),
    ano integer,
    placa character varying(255),
    categoria character varying(255),
    capacidade double precision,
    modelo character varying(255),
    marca character varying(255)
);


ALTER TABLE public.veiculo OWNER TO postgres;

--
-- Name: veiculo_idveiculo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.veiculo_idveiculo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.veiculo_idveiculo_seq OWNER TO postgres;

--
-- Name: veiculo_idveiculo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.veiculo_idveiculo_seq OWNED BY public.veiculo.idveiculo;


--
-- Name: cliente idcliente; Type: DEFAULT; Schema: cliente; Owner: postgres
--

ALTER TABLE ONLY cliente.cliente ALTER COLUMN idcliente SET DEFAULT nextval('cliente.cliente_idcliente_seq'::regclass);


--
-- Name: abastecimento idabastecimento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abastecimento ALTER COLUMN idabastecimento SET DEFAULT nextval('public.abastecimento_idabastecimento_seq'::regclass);


--
-- Name: chat idchat; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat ALTER COLUMN idchat SET DEFAULT nextval('public.chat_idchat_seq'::regclass);


--
-- Name: colaborador idcolaborador; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador ALTER COLUMN idcolaborador SET DEFAULT nextval('public.colaborador_idcolaborador_seq'::regclass);


--
-- Name: ferias idferias; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ferias ALTER COLUMN idferias SET DEFAULT nextval('public.ferias_idferias_seq'::regclass);


--
-- Name: multa idmulta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.multa ALTER COLUMN idmulta SET DEFAULT nextval('public.multa_idmulta_seq'::regclass);


--
-- Name: ocorrencia idocorrencia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia ALTER COLUMN idocorrencia SET DEFAULT nextval('public.ocorrencia_idocorrencia_seq'::regclass);


--
-- Name: situacaousuario idsituacaousuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacaousuario ALTER COLUMN idsituacaousuario SET DEFAULT nextval('public.situacaousuario_idsituacaousuario_seq'::regclass);


--
-- Name: tipoocorrencia idtipoocorrencia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoocorrencia ALTER COLUMN idtipoocorrencia SET DEFAULT nextval('public.tipoocorrencia_idtipoocorrencia_seq'::regclass);


--
-- Name: usuario idusuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN idusuario SET DEFAULT nextval('public.usuario_idusuario_seq'::regclass);


--
-- Name: veiculo idveiculo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo ALTER COLUMN idveiculo SET DEFAULT nextval('public.veiculo_idveiculo_seq'::regclass);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: cliente; Owner: postgres
--

COPY cliente.cliente (idcliente, nome, email, senha) FROM stdin;
\.
COPY cliente.cliente (idcliente, nome, email, senha) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: abastecimento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.abastecimento (idabastecimento, data, cidade, cnpj, quantidade, valortotal, valorunitario, posto, produto, hodometro) FROM stdin;
\.
COPY public.abastecimento (idabastecimento, data, cidade, cnpj, quantidade, valortotal, valorunitario, posto, produto, hodometro) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat (idchat, idusuarioorigem, idusuariodestino, mensagem, visualizada, datahoraenvio, datahoravisualizacao) FROM stdin;
\.
COPY public.chat (idchat, idusuarioorigem, idusuariodestino, mensagem, visualizada, datahoraenvio, datahoravisualizacao) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: colaborador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colaborador (idcolaborador, nome, cpf, email, idfilial, idsituacaousuario) FROM stdin;
\.
COPY public.colaborador (idcolaborador, nome, cpf, email, idfilial, idsituacaousuario) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: ferias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ferias (idferias, datainclusao, datainicio, datafim, idcolaborador, ativo) FROM stdin;
\.
COPY public.ferias (idferias, datainclusao, datainicio, datafim, idcolaborador, ativo) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: filial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.filial (idfilial, fantasia, uf, numerofilial, cnpj) FROM stdin;
\.
COPY public.filial (idfilial, fantasia, uf, numerofilial, cnpj) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: localizacao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.localizacao (idveiculo, datahora, longitude, latitude) FROM stdin;
\.
COPY public.localizacao (idveiculo, datahora, longitude, latitude) FROM '$$PATH$$/3058.dat';

--
-- Data for Name: multa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.multa (idmulta, prefixo, data, placa, infracao, nomemotorista, matriculamotorista, local, valorinflacao, valorpago) FROM stdin;
\.
COPY public.multa (idmulta, prefixo, data, placa, infracao, nomemotorista, matriculamotorista, local, valorinflacao, valorpago) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: ocorrencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ocorrencia (idocorrencia, idusuario, idusuarioinclusao, datainclusao, idtipoocorrencia, dataocorrencia) FROM stdin;
\.
COPY public.ocorrencia (idocorrencia, idusuario, idusuarioinclusao, datainclusao, idtipoocorrencia, dataocorrencia) FROM '$$PATH$$/3061.dat';

--
-- Data for Name: situacaousuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.situacaousuario (idsituacaousuario, descricao) FROM stdin;
\.
COPY public.situacaousuario (idsituacaousuario, descricao) FROM '$$PATH$$/3063.dat';

--
-- Data for Name: tipoocorrencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipoocorrencia (idtipoocorrencia, nome, descricao) FROM stdin;
\.
COPY public.tipoocorrencia (idtipoocorrencia, nome, descricao) FROM '$$PATH$$/3065.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (idusuario, idsituacaousuario, idfilial, nome, email, senha, status, foto, cpf, datanascimento, admissao, idcargousuario) FROM stdin;
\.
COPY public.usuario (idusuario, idsituacaousuario, idfilial, nome, email, senha, status, foto, cpf, datanascimento, admissao, idcargousuario) FROM '$$PATH$$/3067.dat';

--
-- Data for Name: veiculo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.veiculo (idveiculo, idfilial, prefixo, tipo, ano, placa, categoria, capacidade, modelo, marca) FROM stdin;
\.
COPY public.veiculo (idveiculo, idfilial, prefixo, tipo, ano, placa, categoria, capacidade, modelo, marca) FROM '$$PATH$$/3069.dat';

--
-- Name: cliente_idcliente_seq; Type: SEQUENCE SET; Schema: cliente; Owner: postgres
--

SELECT pg_catalog.setval('cliente.cliente_idcliente_seq', 6, true);


--
-- Name: abastecimento_idabastecimento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.abastecimento_idabastecimento_seq', 1, false);


--
-- Name: chat_idchat_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chat_idchat_seq', 103, true);


--
-- Name: colaborador_idcolaborador_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colaborador_idcolaborador_seq', 13, true);


--
-- Name: ferias_idferias_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ferias_idferias_seq', 118, true);


--
-- Name: multa_idmulta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.multa_idmulta_seq', 6639, true);


--
-- Name: ocorrencia_idocorrencia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ocorrencia_idocorrencia_seq', 1, false);


--
-- Name: situacaousuario_idsituacaousuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.situacaousuario_idsituacaousuario_seq', 1, false);


--
-- Name: tipoocorrencia_idtipoocorrencia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipoocorrencia_idtipoocorrencia_seq', 1, false);


--
-- Name: usuario_idusuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_idusuario_seq', 3126, true);


--
-- Name: veiculo_idveiculo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.veiculo_idveiculo_seq', 1580, true);


--
-- Name: abastecimento abastecimento_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.abastecimento
    ADD CONSTRAINT abastecimento_pk PRIMARY KEY (idabastecimento);


--
-- Name: chat chat_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pk PRIMARY KEY (idchat);


--
-- Name: colaborador colaborador_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador
    ADD CONSTRAINT colaborador_cpf_key UNIQUE (cpf);


--
-- Name: colaborador colaborador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador
    ADD CONSTRAINT colaborador_pkey PRIMARY KEY (idcolaborador);


--
-- Name: ferias ferias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ferias
    ADD CONSTRAINT ferias_pkey PRIMARY KEY (idferias);


--
-- Name: filial filial_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.filial
    ADD CONSTRAINT filial_pk PRIMARY KEY (idfilial);


--
-- Name: multa multa_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.multa
    ADD CONSTRAINT multa_pk PRIMARY KEY (idmulta);


--
-- Name: ocorrencia ocorrencia_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia
    ADD CONSTRAINT ocorrencia_pk PRIMARY KEY (idocorrencia);


--
-- Name: situacaousuario situacaousuario_descricao_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacaousuario
    ADD CONSTRAINT situacaousuario_descricao_key UNIQUE (descricao);


--
-- Name: situacaousuario situacaousuario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.situacaousuario
    ADD CONSTRAINT situacaousuario_pk PRIMARY KEY (idsituacaousuario);


--
-- Name: tipoocorrencia tipoocorrencia_descricao_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoocorrencia
    ADD CONSTRAINT tipoocorrencia_descricao_key UNIQUE (descricao);


--
-- Name: tipoocorrencia tipoocorrencia_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoocorrencia
    ADD CONSTRAINT tipoocorrencia_nome_key UNIQUE (nome);


--
-- Name: tipoocorrencia tipoocorrencia_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipoocorrencia
    ADD CONSTRAINT tipoocorrencia_pk PRIMARY KEY (idtipoocorrencia);


--
-- Name: usuario usuario_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_cpf_key UNIQUE (cpf);


--
-- Name: usuario usuario_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_email_key UNIQUE (email);


--
-- Name: usuario usuario_foto_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_foto_key UNIQUE (foto);


--
-- Name: usuario usuario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pk PRIMARY KEY (idusuario);


--
-- Name: veiculo veiculo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_pk PRIMARY KEY (idveiculo);


--
-- Name: veiculo veiculo_placa_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_placa_key UNIQUE (placa);


--
-- Name: veiculo veiculo_prefixo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_prefixo_key UNIQUE (prefixo);


--
-- Name: colaborador colaborador_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador
    ADD CONSTRAINT colaborador_fk FOREIGN KEY (idfilial) REFERENCES public.filial(idfilial);


--
-- Name: colaborador colaborador_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaborador
    ADD CONSTRAINT colaborador_fk1 FOREIGN KEY (idsituacaousuario) REFERENCES public.situacaousuario(idsituacaousuario);


--
-- Name: ferias ferias_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ferias
    ADD CONSTRAINT ferias_fk FOREIGN KEY (idcolaborador) REFERENCES public.colaborador(idcolaborador);


--
-- Name: localizacao localizacao_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localizacao
    ADD CONSTRAINT localizacao_fk0 FOREIGN KEY (idveiculo) REFERENCES public.veiculo(idveiculo);


--
-- Name: ocorrencia ocorrencia_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia
    ADD CONSTRAINT ocorrencia_fk0 FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: ocorrencia ocorrencia_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia
    ADD CONSTRAINT ocorrencia_fk1 FOREIGN KEY (idusuarioinclusao) REFERENCES public.usuario(idusuario);


--
-- Name: ocorrencia ocorrencia_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ocorrencia
    ADD CONSTRAINT ocorrencia_fk2 FOREIGN KEY (idtipoocorrencia) REFERENCES public.tipoocorrencia(idtipoocorrencia);


--
-- Name: usuario usuario_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk0 FOREIGN KEY (idsituacaousuario) REFERENCES public.situacaousuario(idsituacaousuario);


--
-- Name: usuario usuario_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_fk1 FOREIGN KEY (idfilial) REFERENCES public.filial(idfilial);


--
-- Name: veiculo veiculo_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.veiculo
    ADD CONSTRAINT veiculo_fk0 FOREIGN KEY (idfilial) REFERENCES public.filial(idfilial);


--
-- PostgreSQL database dump complete
--

